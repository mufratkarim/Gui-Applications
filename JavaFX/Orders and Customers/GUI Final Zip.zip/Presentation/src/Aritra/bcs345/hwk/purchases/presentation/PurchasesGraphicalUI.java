package Aritra.bcs345.hwk.purchases.presentation;

import javafx.application.Application;

public class PurchasesGraphicalUI {
	
	public void ShowUI() {

		Application.launch(PurchasesApplication.class);
	
	
	}
}
